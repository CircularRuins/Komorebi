import { LucideIcon } from 'lucide-react';

export interface Feature {
  title: string;
  description: string;
  icon: LucideIcon;
}

export interface SocialLink {
  label: string;
  href: string;
  icon?: LucideIcon;
}

export interface Acknowledgement {
  name: string;
  url: string;
}
