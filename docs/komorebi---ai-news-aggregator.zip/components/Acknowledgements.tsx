import React, { useState } from 'react';
import { ACKNOWLEDGEMENTS, SPONSORS_LINKS } from '../constants';
import { ExternalLink, Heart } from 'lucide-react';

const Acknowledgements: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'acknowledgements' | 'sponsors'>('acknowledgements');

  return (
    <section id="acknowledgements" className="py-20 bg-white border-t border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Tab Navigation */}
        <div className="flex justify-center mb-16">
          <div className="bg-gray-100 p-1.5 rounded-full inline-flex relative">
            <button
              onClick={() => setActiveTab('acknowledgements')}
              className={`relative z-10 px-8 py-2.5 rounded-full text-sm font-medium transition-all duration-300 ${
                activeTab === 'acknowledgements' 
                  ? 'bg-white text-komorebi-900 shadow-sm' 
                  : 'text-gray-500 hover:text-gray-900'
              }`}
            >
              Acknowledgements
            </button>
            <button
              onClick={() => setActiveTab('sponsors')}
              className={`relative z-10 px-8 py-2.5 rounded-full text-sm font-medium transition-all duration-300 ${
                activeTab === 'sponsors' 
                  ? 'bg-white text-komorebi-900 shadow-sm' 
                  : 'text-gray-500 hover:text-gray-900'
              }`}
            >
              Support Us
            </button>
          </div>
        </div>
        
        {/* Content Area */}
        <div className="min-h-[400px]">
          {activeTab === 'acknowledgements' && (
            <div className="animate-fade-in-up">
              <div className="text-center mb-12">
                <h2 className="text-2xl md:text-3xl font-serif font-bold text-gray-900 mb-4">
                    Standing on the Shoulders of Giants
                </h2>
                <p className="text-gray-500">
                    Komorebi wouldn't be possible without these incredible open-source projects.
                </p>
              </div>

              <div className="flex flex-wrap justify-center gap-4 max-w-4xl mx-auto">
                {ACKNOWLEDGEMENTS.map((item) => (
                    <a 
                    key={item.name}
                    href={item.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group flex items-center space-x-2 px-5 py-3 rounded-xl bg-gray-50 hover:bg-komorebi-50 border border-gray-100 hover:border-komorebi-200 transition-all text-gray-600 hover:text-komorebi-700"
                    >
                    <span className="font-medium text-sm">{item.name}</span>
                    <ExternalLink className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </a>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'sponsors' && (
            <div className="animate-fade-in-up">
              <div className="relative rounded-3xl bg-komorebi-800 overflow-hidden px-8 py-16 md:px-16 text-center max-w-4xl mx-auto">
                  {/* Background pattern */}
                  <div className="absolute inset-0 opacity-10 pointer-events-none">
                      <svg className="h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                          <path d="M0 100 C 20 0 50 0 100 100 Z" fill="white" />
                      </svg>
                  </div>
                  
                  <div className="relative z-10">
                      <Heart className="w-12 h-12 text-komorebi-300 mx-auto mb-6" />
                      <h2 className="text-3xl font-serif font-bold text-white mb-6">Support Komorebi</h2>
                      <p className="text-komorebi-100 max-w-2xl mx-auto mb-10 text-lg">
                          This project is 100% open source and free. If you enjoy the calm focus it brings to your workflow, consider buying me a coffee.
                      </p>
                      
                      <div className="flex flex-col sm:flex-row justify-center gap-4">
                          {SPONSORS_LINKS.map((link) => (
                              <a
                                  key={link.label}
                                  href={link.href}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="flex items-center justify-center gap-2 px-6 py-3 bg-white text-komorebi-900 rounded-lg font-semibold hover:bg-komorebi-50 transition-colors shadow-lg"
                              >
                                  {link.icon && <link.icon className="w-4 h-4" />}
                                  <span>{link.label}</span>
                              </a>
                          ))}
                      </div>
                  </div>
              </div>
            </div>
          )}
        </div>

      </div>
    </section>
  );
};

export default Acknowledgements;