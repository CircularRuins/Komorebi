import React from 'react';
import { Download, Monitor, Apple } from 'lucide-react';
import { APP_NAME, TAGLINE, DOWNLOAD_URL, SCREENSHOT_URL } from '../constants';
import SunlightEffect from './SunlightEffect';

const Hero: React.FC = () => {
  return (
    <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-28 overflow-hidden">
      <SunlightEffect />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-serif font-bold text-komorebi-900 tracking-tight mb-6 animate-fade-in-up">
            {APP_NAME}
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 mb-8 leading-relaxed animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
            {TAGLINE}
          </p>
          <p className="text-md text-komorebi-600 mb-10 max-w-2xl mx-auto animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
            Tailored for AI professionals. Keep pace with visionary insights, trending news, and state-of-the-art papers without the noise.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
            <a 
              href={DOWNLOAD_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-3.5 bg-komorebi-600 text-white rounded-full font-semibold hover:bg-komorebi-700 transition-all shadow-lg hover:shadow-xl hover:-translate-y-1"
            >
              <Download className="w-5 h-5" />
              <span>Download for Free</span>
            </a>
            <a 
              href="https://github.com/CircularRuins/Komorebi"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-3.5 bg-white text-gray-700 border border-gray-200 rounded-full font-semibold hover:bg-gray-50 transition-all shadow-sm hover:shadow-md"
            >
              <span className="text-sm text-gray-500">View on GitHub</span>
            </a>
          </div>

          <div className="mt-8 flex items-center justify-center gap-6 text-sm text-gray-500 animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
            <span className="flex items-center gap-1.5"><Monitor className="w-4 h-4" /> Windows</span>
            <span className="w-1 h-1 rounded-full bg-gray-300" />
            <span className="flex items-center gap-1.5"><Apple className="w-4 h-4" /> macOS</span>
          </div>
        </div>

        <div className="mt-16 relative rounded-xl shadow-2xl overflow-hidden border border-gray-200 bg-white animate-fade-in-up" style={{ animationDelay: '0.6s' }}>
            <img 
              src={SCREENSHOT_URL} 
              alt="Komorebi Interface" 
              className="w-full h-auto block"
              loading="lazy"
            />
        </div>
      </div>
    </section>
  );
};

export default Hero;