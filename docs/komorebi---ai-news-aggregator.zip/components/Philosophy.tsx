import React from 'react';
import { PHILOSOPHY } from '../constants';
import { Sun } from 'lucide-react';

const Philosophy: React.FC = () => {
  return (
    <section id="philosophy" className="py-24 bg-komorebi-50 relative overflow-hidden">
        {/* Background decorative element */}
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-komorebi-200/30 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-72 h-72 bg-yellow-100/40 rounded-full blur-3xl"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          <div className="flex-1 space-y-8">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-komorebi-100 text-komorebi-800 text-sm font-medium">
                <Sun className="w-4 h-4" />
                <span>Our Vision</span>
            </div>
            
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-gray-900 leading-tight">
              {PHILOSOPHY.title} <br/>
              <span className="text-komorebi-600 italic">{PHILOSOPHY.subtitle}</span>
            </h2>

            <div className="prose prose-lg text-gray-600 space-y-6">
                <p>{PHILOSOPHY.description1}</p>
                <p>{PHILOSOPHY.description2}</p>
                <div className="pl-6 border-l-4 border-komorebi-400 italic text-gray-700">
                    <p>{PHILOSOPHY.description3}</p>
                </div>
            </div>
          </div>

          <div className="flex-1 flex justify-center lg:justify-end">
             <div className="relative w-80 h-96 lg:w-96 lg:h-[30rem]">
                {/* Abstract visualization of Komorebi - Sunlight through trees */}
                <div className="absolute inset-0 bg-gray-900 rounded-[2rem] overflow-hidden shadow-2xl transform rotate-3 hover:rotate-0 transition-all duration-700">
                    {/* Dark tree silhouettes */}
                    <div className="absolute inset-0 bg-gradient-to-b from-komorebi-900 to-black opacity-90"></div>
                    
                    {/* Light beams */}
                    <div className="absolute -top-20 -left-20 w-[150%] h-[50%] bg-white/10 blur-2xl rotate-45 transform origin-top-left animate-float"></div>
                    <div className="absolute top-[20%] -left-10 w-[150%] h-[30%] bg-white/5 blur-xl rotate-45 transform origin-top-left animate-float" style={{animationDelay: '1s'}}></div>
                    
                    {/* Particles */}
                    <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-center p-8">
                            <span className="text-6xl text-white/90 font-serif">木</span>
                            <span className="text-6xl text-white/90 font-serif">漏</span>
                            <span className="text-6xl text-white/90 font-serif">れ</span>
                            <span className="text-6xl text-white/90 font-serif">日</span>
                            <p className="text-komorebi-200 mt-4 text-sm uppercase tracking-widest">Sunlight filtering through trees</p>
                        </div>
                    </div>
                </div>
             </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Philosophy;
