import React from 'react';

const SunlightEffect: React.FC = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
      {/* Abstract light beams */}
      <div className="absolute top-[-50%] left-[-20%] w-[100%] h-[200%] bg-gradient-to-br from-yellow-50/40 via-transparent to-transparent rotate-12 blur-3xl" />
      <div className="absolute top-[-20%] right-[-10%] w-[80%] h-[150%] bg-gradient-to-bl from-green-100/30 via-transparent to-transparent -rotate-12 blur-3xl" />
      
      {/* "Leaves" shadows - using simple SVG patterns or CSS shapes */}
      <div className="absolute top-0 left-0 w-full h-full opacity-20">
         <svg width="100%" height="100%">
            <defs>
              <pattern id="leaves" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
                <circle cx="10" cy="10" r="2" fill="#759b83" className="animate-pulse" style={{animationDuration: '4s'}}/>
                <circle cx="50" cy="60" r="3" fill="#759b83" className="animate-pulse" style={{animationDuration: '7s'}}/>
                <circle cx="80" cy="20" r="1" fill="#759b83" className="animate-pulse" style={{animationDuration: '5s'}}/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#leaves)" />
         </svg>
      </div>
    </div>
  );
};

export default SunlightEffect;
