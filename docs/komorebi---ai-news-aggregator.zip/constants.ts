import { 
  Layout, 
  Rss, 
  Zap, 
  BrainCircuit, 
  Github, 
  Coffee, 
  Download,
  Heart
} from 'lucide-react';
import { Feature, Acknowledgement, SocialLink } from './types';

export const APP_NAME = "Komorebi";
export const TAGLINE = "A curated window into the world of AI.";
export const LOGO_URL = "https://github.com/user-attachments/assets/69a65cc5-d366-4d99-81d2-a4e1072ce525";
export const SCREENSHOT_URL = "https://github.com/user-attachments/assets/ce3de2ae-d43c-4f54-a41a-21657d1ca6e6";

export const DOWNLOAD_URL = "https://github.com/CircularRuins/Komorebi/releases";
export const GITHUB_URL = "https://github.com/CircularRuins/Komorebi";

export const FEATURES: Feature[] = [
  {
    title: "Simple UI",
    description: "Minimalist design focusing on reading experience. Supports English, 简体中文, Español, and 日本語.",
    icon: Layout
  },
  {
    title: "Diverse Sources",
    description: "Tailored feeds for AI professionals: visionary insights, trending news, product launches, and arXiv papers.",
    icon: Rss
  },
  {
    title: "Dynamic Content",
    description: "Seamlessly renders articles, videos, tweets, and newsletters in a unified, compelling interface.",
    icon: Zap
  },
  {
    title: "LLM-Powered",
    description: "Enhance your reading with AI-driven translation, summarization, and key insight extraction.",
    icon: BrainCircuit
  }
];

export const PHILOSOPHY = {
  title: "Product Philosophy",
  subtitle: "木漏れ日 (Komorebi)",
  description1: "Komorebi is a Japanese word that describes the soft, dappled sunlight filtering through leaves and trees.",
  description2: "Today, AI is the hottest field—like the sun itself. An overwhelming flood of news, products, and research shines down relentlessly, often leaving people burned out and anxious rather than informed.",
  description3: "Komorebi is designed to be a filter, not another beam of direct light. By carefully curating information sources and refining product features, it transforms the experience of staying informed into something calm, focused, and enjoyable—like standing beneath the trees, absorbing only the gentle warmth of komorebi."
};

export const ACKNOWLEDGEMENTS: Acknowledgement[] = [
  { name: "Fluent Reader", url: "https://github.com/yang991178/fluent-reader" },
  { name: "BestBlogs", url: "https://github.com/ginobefun/BestBlogs" },
  { name: "longcut", url: "https://github.com/SamuelZ12/longcut" },
  { name: "kill-the-newsletter", url: "https://github.com/leafac/kill-the-newsletter" },
  { name: "arxiv-rss-feed-generator", url: "https://github.com/postlight/mercury-parser" },
  { name: "youtube-transcript-api", url: "https://github.com/jdepoix/youtube-transcript-api" },
  { name: "alphaXiv", url: "https://www.alphaxiv.org/" },
  { name: "youtube_rss_extractor", url: "https://github.com/jeffkeeling/youtube_rss_extractor" }
];

export const SPONSORS_LINKS: SocialLink[] = [
  { label: "GitHub Sponsors", href: "https://github.com/sponsors/yang991178", icon: Heart },
  { label: "PayPal", href: "https://www.paypal.me/yang991178", icon: Coffee },
];
